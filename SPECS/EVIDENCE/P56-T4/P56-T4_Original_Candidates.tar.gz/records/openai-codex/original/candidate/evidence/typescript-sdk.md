Source excerpt

# Codex SDK

Embed the Codex agent in your workflows and apps.

The TypeScript SDK wraps the `codex` CLI from `@openai/codex`. It spawns the CLI and exchanges JSONL events over stdin/stdout.

Requires Node.js 18+.

Call `run()` repeatedly on the same `Thread` instance to continue that conversation.

`run()` buffers events until the turn finishes. To react to intermediate progress—tool calls, streaming responses, and file change notifications—use `runStreamed()` instead, which returns an async generator of structured events.

The Codex agent can produce a JSON response that conforms to a specified schema. The schema can be provided for each turn as a plain JSON object.

Provide structured input entries when you need to include images alongside text. Text entries are concatenated into the final prompt while image entries are passed to the Codex CLI via `--image`.

Threads are persisted in `~/.codex/sessions`. If you lose the in-memory `Thread` object, reconstruct it with `resumeThread()` and keep going.

Codex runs in the current working directory by default. To avoid unrecoverable errors, Codex requires the working directory to be a Git repository. You can skip the Git repository check by passing the `skipGitRepoCheck` option when creating a thread.

By default, the Codex CLI inherits the Node.js process environment. Provide the optional `env` parameter when instantiating the `Codex` client to fully control which variables the CLI receives—useful for sandboxed hosts like Electron apps.

Use the `config` option to provide additional Codex CLI configuration overrides.

Provenance

- Repository: https://github.com/openai/codex
- Pinned revision: 16d7daad7c5dc73da8558102a65bb7d7709807e1
- Source path: sdk/typescript/README.md
- Source range: lines 1-5, 13, 28, 36, 55, 88, 100, 110, 121-138
- Full-file SHA-256: 1d3787c793afa4b32b00bb538e079f313259c84b65e5c1f4192190052737242e

Author notes

- The excerpt supports the SDK integration shape and documented workspace controls, not a guarantee that any requested code change succeeds.
- The source uses a machine-local session path as documentation; the candidate records it only as a source fact, not as an implementation binding.
