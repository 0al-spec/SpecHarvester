Source excerpt

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

OpenAI Codex
Copyright 2025 OpenAI

This project includes code derived from [Ratatui](https://github.com/ratatui/ratatui), licensed under the MIT license.
Copyright (c) 2016-2022 Florian Dehau
Copyright (c) 2023-2025 The Ratatui Developers

Provenance

- Repository: https://github.com/openai/codex
- Pinned revision: 16d7daad7c5dc73da8558102a65bb7d7709807e1
- Source paths: LICENSE; NOTICE
- Source ranges: LICENSE lines 1-3; NOTICE lines 1-6
- Full-file SHA-256 (LICENSE): d17f227e4df5da1600391338865ce0f3055211760a36688f816941d58232d8dc
- Full-file SHA-256 (NOTICE): 9d71575ecfd9a843fc1677b0efb08053c6ba9fd686a0de1a6f5382fd3c220915

Author notes

- The repository states Apache-2.0 for the project and separately identifies Ratatui-derived material under MIT. Reviewers should inspect the complete upstream notices before redistribution.
