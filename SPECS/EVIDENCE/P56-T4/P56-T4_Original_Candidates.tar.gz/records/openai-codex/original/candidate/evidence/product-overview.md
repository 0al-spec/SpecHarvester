Source excerpt

<p align="center"><strong>Codex CLI</strong> is a coding agent from OpenAI that runs locally on your computer.

Run the following on Mac or Linux to install Codex CLI:

```shell
curl -fsSL https://chatgpt.com/codex/install.sh | sh
```

Then simply run `codex` to get started.

Run `codex` and select **Sign in with ChatGPT**. We recommend signing into your ChatGPT account to use Codex as part of your Plus, Pro, Business, Edu, or Enterprise plan.

You can also use Codex with an API key, but this requires [additional setup](https://developers.openai.com/codex/auth#sign-in-with-an-api-key).

This repository is licensed under the [Apache-2.0 License](LICENSE).

Provenance

- Repository: https://github.com/openai/codex
- Pinned revision: 16d7daad7c5dc73da8558102a65bb7d7709807e1
- Source path: README.md
- Source range: lines 1, 16-20, 50, 68-72, 81
- Full-file SHA-256: ba4e1f69ff48386e72a9c5e1edaf76aad64a475c2d51af79ccba6d1128261ba7

Author notes

- The excerpt distinguishes the local CLI from the desktop and cloud products; those products are excluded from this candidate.
- Authentication is documented at a high level only. No credential or endpoint is copied here.
