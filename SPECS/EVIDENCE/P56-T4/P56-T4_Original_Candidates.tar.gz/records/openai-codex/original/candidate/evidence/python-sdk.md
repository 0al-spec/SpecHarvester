Source excerpt

# OpenAI Codex Python SDK

Build Python applications that start Codex threads, run turns, stream progress,
and control workspace access.

The SDK reuses your existing Codex authentication when one is already
available:

`thread.run(...)` returns a `TurnResult` containing the final response,
collected items, and token usage.

```python
with Codex() as codex:
    thread = codex.thread_start()
    result = thread.run("Explain this repository in three bullets.")
    print(result.final_response)
```

Source code excerpt

```python
class CodexClient:
    """Synchronous typed JSON-RPC client for `codex app-server` over stdio."""

        approval_handler: ApprovalHandler | None = None,

            args.extend(["app-server", "--listen", "stdio://"])
```

Provenance

- Repository: https://github.com/openai/codex
- Pinned revision: 16d7daad7c5dc73da8558102a65bb7d7709807e1
- Source paths: sdk/python/README.md; sdk/python/src/openai_codex/client.py
- Source ranges: README.md lines 1-4, 14-29; client.py lines 212-218, 246-252
- Full-file SHA-256 (README.md): a2b0ca0160239ad8b816067df782d68be0831cbaa7a80bf85d2e39e8f2bf0cb7
- Full-file SHA-256 (client.py): 76bdb1e63c62987c3530ea763e9655a06b308cbc4e18cb51958e85b6c23aec3b

Author notes

- The app-server excerpt establishes process transport and the presence of an approval callback, but not approval semantics or a secure default.
- The API documentation does not state the minimum Python version; that remains unknown.
