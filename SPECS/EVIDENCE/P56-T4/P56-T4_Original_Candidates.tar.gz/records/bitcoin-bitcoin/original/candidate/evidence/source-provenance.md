Repository: https://github.com/bitcoin/bitcoin
Pinned revision: a2aab6df97d9f3e1186e8c3fc57ad909cc8aef9b

Portable source references and full-file SHA-256 digests:

- README.md, lines 12-14 and 18-22, SHA-256 45916e6961540c536e8b17b3a4d3305393afce5b407d1ea3da82c246cba8aa5d
- doc/README.md, lines 16-22, SHA-256 efa121f49b44bb110d7ddead48106f6f71db71d0d9b619e85f38193f525a06e8
- CMakeLists.txt, lines 103-122, SHA-256 c7ce45f448c9104a47a765638631695fee1311de19f94d08e65de1538fcdbfc3
- src/CMakeLists.txt, lines 162-180, 313-326, 354-366 and 398-400, SHA-256 049cb55c817ef25e01c6fe4610435b284498b1fabd758608dcac42980100b8d9
- doc/JSON-RPC-interface.md, lines 3-27, 43-50 and 95-137, SHA-256 0d92a9f8b0319373462e93a02ba414fd5f61f173e89366d430227776ba23f4bd
- doc/files.md, lines 62-76, 143-164, SHA-256 003ac26441b44e8dc5a5f31bf749816483edd47996dadecb9dcd455ea75e0cfc
- doc/bitcoin-conf.md, lines 3-17, SHA-256 f0e4ef5eae69a3670f5a9c38597850900dadd770d4a3eb51201c63c5554034c7

The excerpts are copied as documentation evidence. No build, runtime, or
conformance execution was performed for this candidate. The candidate does not
establish exhaustive interface coverage, resource limits, release stability, or
security isolation. The REST interface is intentionally outside the bounded
surface because this candidate focuses on the node, RPC, wallet, and GUI paths.
