option(BUILD_DAEMON "Build bitcoind executable." ON)
option(BUILD_GUI "Build bitcoin-qt executable." OFF)
option(BUILD_CLI "Build bitcoin-cli executable." ON)
option(ENABLE_WALLET "Enable wallet." ON)
cmake_dependent_option(BUILD_WALLET_TOOL "Build bitcoin-wallet tool." ${BUILD_TESTS} "ENABLE_WALLET" OFF)

if(ENABLE_WALLET)
  add_subdirectory(wallet)
endif()

if(BUILD_DAEMON)
  add_executable(bitcoind
    bitcoind.cpp
    init/bitcoind.cpp
  )
endif()

if(BUILD_CLI)
  add_executable(bitcoin-cli bitcoin-cli.cpp init/basic.cpp)
endif()

if(BUILD_GUI)
  add_subdirectory(qt)
endif()
