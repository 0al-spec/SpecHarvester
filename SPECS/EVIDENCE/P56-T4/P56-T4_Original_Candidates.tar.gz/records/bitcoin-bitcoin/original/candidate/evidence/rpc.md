The headless daemon `bitcoind` has the JSON-RPC API enabled by default, the GUI
`bitcoin-qt` has it disabled by default. This can be changed with the `-server`
option. In the GUI it is possible to execute RPC methods in the Debug Console
Dialog.

There are two JSON-RPC endpoints on the server:

1. `/`
2. `/wallet/<walletname>/`

This endpoint is always active.
It can always service non-wallet requests and can service wallet requests when
exactly one wallet is loaded.

This endpoint is only activated when the wallet component has been compiled in.
It can service both wallet and non-wallet requests.
It MUST be used for wallet requests when two or more wallets are loaded.

The JSON-RPC server supports both _by-position_ and _by-name_ parameter
structures described in the JSON-RPC specification.

The RPC interface allows other programs to control Bitcoin Core,
including the ability to spend funds from your wallets, affect consensus
verification, read private data, and otherwise perform operations that
can cause loss of money, data, or privacy.

By default, the RPC interface can
only be accessed by a client running on the same computer and only
after the client provides a valid authentication credential (username
and passphrase).

Do not enable RPC connections over the public Internet. Although Bitcoin Core's
RPC interface does use authentication, it does not use encryption, so your login
credentials are sent as clear text that can be read by anyone on your network
path.
