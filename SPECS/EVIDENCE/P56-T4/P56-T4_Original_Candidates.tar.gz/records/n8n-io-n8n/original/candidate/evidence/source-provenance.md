Source repository: https://github.com/n8n-io/n8n
Pinned revision: 082b5d9190f4bc81d93c6a94d6d4692bed4660ca

Portable source references and full-file SHA-256 digests:

- README.md, lines 1-33 and 49-55; SHA-256 `9af8818267836df37f8d58cbb1db8c02c83cbd110118361811f4910d4de59eca`
- packages/@n8n/instance-ai/README.md, lines 1-30; SHA-256 `317a18f9ca5b64cbc269ccf161caecc0c98c1e0fe69a95c2701c0df405141307`
- packages/@n8n/instance-ai/docs/tools.md, lines 107-145 and 177-209; SHA-256 `4f2bea0119e2957280a14968f12dd0cfe49eae1955f75e270e414331ddcf1fe3`
- packages/@n8n/instance-ai/docs/configuration.md, lines 1-18, 42-89, 109-127, and 165-175; SHA-256 `6081074413dad9cbee3eb884dc3776ca98c3221bf0042b05903ca969faf1a2d1`
- packages/@n8n/instance-ai/docs/sandboxing.md, lines 1-5 and 43-54; SHA-256 `4c3b7877f489adc344a5c68bc390b42a9e51586cc10c233177f149a96c4879c2`
- LICENSE.md, lines 1-14 and 16-35; SHA-256 `d2f621f59aa4c10eab79b6333e59d9d3d5b53307dcfd16dbd75e40e679e84965`

Evidence excerpts are copied from the pinned snapshot. The excerpts do not establish complete product coverage, runtime safety, HTTP route completeness, or license permission for a specific deployment; those remain review questions.
