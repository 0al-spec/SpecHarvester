# @n8n/instance-ai

Instance AI is the agent runtime behind the AI assistant experience in n8n. It
lets users ask for help with workflows, executions, credentials, nodes, and
workflow building from inside an n8n instance.

The package contains the agent prompts, tool registry, workflow-builder logic,
workspace adapters, tracing helpers, and evaluation harnesses. The HTTP API,
database entities, settings, and n8n service adapters live in
`packages/cli/src/modules/instance-ai`.

## What It Does

Instance AI is built around a deep-agent loop:

- An orchestrator agent receives the user's request and maintains the plan.
- Most work runs in the orchestrator; eval setup uses a focused background agent.
- Domain tools read and update n8n resources through backend adapters.
- Observational memory condenses long conversations.
- Workflow building runs in a sandbox workspace, validates generated TypeScript,
  and submits the workflow through the n8n backend.

The workflow builder requires sandboxing. The default provider is the n8n
sandbox service. Daytona remains an explicit provider for environments that
still need it.

## Running Locally

Instance AI is a backend module, so run it through n8n rather than this package
directly.

