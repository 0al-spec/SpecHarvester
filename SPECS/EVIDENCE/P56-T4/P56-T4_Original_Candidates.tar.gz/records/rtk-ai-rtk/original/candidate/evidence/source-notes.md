# Portable Provenance

Repository: https://github.com/rtk-ai/rtk
Pinned revision: 7da2674073394194754a228d346189a74869e6ba

The excerpt files are copied unchanged from the cited source ranges. SHA-256 values below are for the complete source files, not the excerpts.

| Evidence | Original relative path | Range | Full-file SHA-256 |
|---|---|---:|---|
| readme-excerpt.md | README.md | 37-64, 111-134 | 9eedab13449e48321140887bad972786f1faa25ac5b4120f0259f4086dd601e9 |
| main-excerpt.rs | src/main.rs | 640-645, 836-847, 2495-2505 | 695842e2f300dfe18c0dd00f097fefd59c82e7245eb911589757e14ba742752c |
| runner-excerpt.rs | src/core/runner.rs | 9-19, 107-156, 256-269 | 10735ee99a3a1ae99e19bf2f1b0b902dc0246c9e3e014e66abbf4441c0ac6dcc |
| rewrite-excerpt.rs | src/hooks/rewrite_cmd.rs | 1-17, 47-64 | f51ef85e22df0087dd1b5ff0ccff10e87adca2454e66522a4c9b8ea569727a84 |
| search-compress-excerpt.rs | tests/search_compress_test.rs | 1-4, 27-52, 201-223, 225-230 | a28ee4d6537153e06c6e96081b0114d623033831122bdd08b415c795ac809640 |
| package metadata | Cargo.toml | 1-13, 38-39 | c09dac98af035430e8b1e16dd75cdc91a0c682ecd863922408c2a5650da505da |
| configuration-excerpt.md | docs/guide/getting-started/configuration.md | 8-28, 66-75, 56-64, 113-128 | 3ffa553ac613adbf275ddcad1c0be2e91484fe83bfeb8865e043f48654bb86e4 |

## Author Notes

- The README calls the supported-command count and overhead approximate product claims; the package does not promote them to guarantees.
- The token estimate is documented as bytes divided by four and is not a tokenizer or billing measurement.
- The test excerpt demonstrates selected grep behavior and a fixture-level savings assertion; it does not establish universal compression or semantic equivalence for all commands.
- The README documents Linux, macOS, and Windows distribution targets, while the selected Unix integration test is conditional; platform behavior outside those documented targets remains unverified here.
- Telemetry and configuration details were reviewed in the pinned snapshot but are recorded as declared optional effects rather than independently verified runtime receipts.
