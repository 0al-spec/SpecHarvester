#![cfg(unix)]
//! Integration tests for the shared grep/rg compression filter: the GROUP path
//! with context flags (-A/-B/-C) and the safety-net passthrough for flags (some
//! grep-only like -I, some rg-only like --heading/-p) that break the NUL reparse.

use std::process::Command;

fn rtk() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rtk"))
}

fn rg_available() -> bool {
    Command::new("rg")
        .arg("--version")
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn write_temp(content: &str) -> (tempfile::TempDir, std::path::PathBuf) {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("test.txt");
    std::fs::write(&path, content).expect("write");
    (dir, path)
}

// --- context compression (the gain win) ---

#[test]
fn single_file_context_shown_without_header() {
    if !rg_available() {
        return;
    }
    let long = "x".repeat(120);
    let content =
        format!("before {long}\nMATCH {long}\nafter1 {long}\nafter2 {long}\nend {long}\n");
    let (_dir, path) = write_temp(&content);
    let out = rtk()
        .args(["grep", "-A2", "MATCH", path.to_str().unwrap()])
        .output()
        .expect("rtk grep");
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert!(
        !stdout.contains("matches in"),
        "single-file search must not add a grouped header:\n{stdout}"
    );
    assert!(
        stdout.contains("after1") && stdout.contains("after2"),
        "after-context lines must be shown:\n{stdout}"
    );
}

// --- shape flags: passthrough, no NUL leak ---

#[test]
fn column_flag_output_has_no_nul() {
    if !rg_available() {
        return;
    }
    let (_dir, path) = write_temp("hello world\n");
    let out = rtk()
        .args(["rg", "--column", "hello", path.to_str().unwrap()])
        .output()
        .expect("rtk grep");
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert!(
        !stdout.contains('\u{0}'),
        "--column output must not contain NUL:\n{stdout:?}"
    );
    assert!(
        stdout.contains("hello"),
        "--column output must contain the match:\n{stdout}"
    );
}

// --- token savings (the compression gain) ---

fn count_tokens(s: &str) -> usize {
    s.split_whitespace().count()
}

#[test]
fn bulky_grep_yields_token_savings() {
    if !rg_available() {
        return;
    }
    let filler: String = (0..50).map(|i| format!("word{i} ")).collect();
    let mut content = String::new();
    for i in 0..60 {
        content.push_str(&format!("MATCH line {i} {filler}\n"));
    }
    let (_dir, path) = write_temp(&content);

    let raw = Command::new("rg")
        .args(["-nH", "MATCH", path.to_str().unwrap()])
        .output()
        .expect("rg");
    let raw_tokens = count_tokens(&String::from_utf8_lossy(&raw.stdout));

    let out = rtk()
        .args(["grep", "MATCH", path.to_str().unwrap()])
        .output()
        .expect("rtk grep");
    let rtk_tokens = count_tokens(&String::from_utf8_lossy(&out.stdout));

    let savings = 100.0 - (rtk_tokens as f64 / raw_tokens as f64 * 100.0);
    assert!(
        savings >= 50.0,
        "expected >=50% token savings, got {savings:.1}% (raw={raw_tokens}, rtk={rtk_tokens})"
    );
}
